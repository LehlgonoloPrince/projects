# injozi back-end challenge 

Requirements:
click
Flask
Flask-Cors
pymong
Flask-Bcrypt
PyJWT
The API uses **Mongodb** as the database and **JWT** for Authentication
When creating a user, the password is hashed just to add multiple layers of defence.


```
